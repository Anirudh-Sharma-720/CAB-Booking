package com.service;

public interface IEmailService {
	
		public String sendEmail(String to, String body, String subject);
	
}
