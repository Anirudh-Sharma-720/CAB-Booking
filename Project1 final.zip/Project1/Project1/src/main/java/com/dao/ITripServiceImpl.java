package com.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Driver;
import com.entities.TripBooking;
import com.repository.ICabRepository;
import com.repository.IDriverRepository;
//import com.exception.DriverNotFoundException;
import com.repository.ITripBookingRepository;
import com.service.ITripBookingService;
import java.util.*;
import com.entities.*;
@Service
public class ITripServiceImpl implements ITripBookingService{
	@Autowired
	private ITripBookingRepository tripBookingRepository;

	@Autowired ICabRepository cabRepo;
	@Autowired IDriverRepository drivRepo;
	@Override
	public TripBooking insertTripBooking(TripBooking tripBooking) {
		tripBooking.setCab(this.assignCab(tripBooking.getCab().getCarType()));
	tripBooking.setDriver(this.assignDriver(tripBooking.getCab()));
	tripBooking.setBill(calculateBill(tripBooking));
		TripBooking tripBookingObj = tripBookingRepository.save(tripBooking);
		return tripBookingObj;
	}

	@Override
	public TripBooking updateTripBooking(int tripBookingId, TripBooking tripBooking){
		TripBooking tripBookingObj = tripBookingRepository.findById(tripBookingId).get();
		tripBookingObj.setCustomerId(tripBooking.getCustomerId());
		tripBookingObj.setDriver(tripBooking.getDriver());
		tripBookingObj.setFromLocation(tripBooking.getFromLocation());
		tripBookingObj.setToLocation(tripBooking.getToLocation());
		tripBookingObj.setFromDateTime(tripBooking.getFromDateTime());
		tripBookingObj.setToDateTime(tripBooking.getToDateTime());
		tripBookingObj.setStatus(tripBooking.isStatus());
		tripBookingObj.setDistanceInKm(tripBooking.getDistanceInKm());
		tripBookingObj.setBill(tripBooking.getBill());
		
		tripBookingRepository.deleteById(tripBookingId);
		TripBooking updatedTripBooking = tripBookingRepository.save(tripBookingObj);
		return updatedTripBooking;
	}

	@Override
	public TripBooking deleteTripBooking(int tripBookingId){
		 
		TripBooking tripBookingObj = tripBookingRepository.findById(tripBookingId).get();
		if(tripBookingRepository.existsById(tripBookingId))
			tripBookingRepository.deleteById(tripBookingId);
		return tripBookingObj;
	}

	@Override
	public List<TripBooking> viewAllTripsCustomer(int customerId){
		List<TripBooking> bestTripsCustomer = tripBookingRepository.viewAllTripsCustomer(customerId);
		return bestTripsCustomer;
	}

	//@Override
	public Driver viewDriver(int tripBookingId){
		TripBooking tripBookingObj = tripBookingRepository.findById(tripBookingId).get();
		return tripBookingObj.getDriver();
	}


	@Override
	public float calculateBill(TripBooking trip) {
		// TODO Auto-generated method stub
	
		int tripDist=this.distanceInKm(trip);
		trip.setDistanceInKm(tripDist);
		float bill=tripDist*trip.getCab().getPerKmRate();
		return bill;
	}
	public List<TripBooking> viewTripsCabwise(int cabId){
		return tripBookingRepository.getTripsCabwise(cabId);
	
	}
	public List<TripBooking> getAllTrips(){
		return tripBookingRepository.findAll();	}
	public TripBooking getTripById(int tripId){
		return tripBookingRepository.findById(tripId).get();
	}
	public Driver assignDriver(Cab cab) {
		return drivRepo.viewByCab(cab.getCabId());
	}
	public Cab assignCab(String carType) {
		List<Cab> cabs=cabRepo.assignCab(carType);
		return cabs.get(0);
	}
	
	
	public int distanceInKm(TripBooking trip) {
		if(trip.getFromLocation().equals("Delhi") && trip.getToLocation().equals("Mumbai"))return 1400;
		if(trip.getFromLocation().equals("Delhi") && trip.getToLocation().equals("Jaipur"))return 280;
		if(trip.getFromLocation().equals("Delhi") && trip.getToLocation().equals("Goa"))return 1900;
		if(trip.getFromLocation().equals("Delhi") && trip.getToLocation().equals("Kolkata"))return 1600;
		if(trip.getFromLocation().equals("Mumbai") && trip.getToLocation().equals("Delhi"))return 1400;
		if(trip.getFromLocation().equals("Mumbai") && trip.getToLocation().equals("Jaipur"))return 1150;
		if(trip.getFromLocation().equals("Mumbai") && trip.getToLocation().equals("Kolkata"))return 1900;
		if(trip.getFromLocation().equals("Mumbai") && trip.getToLocation().equals("Goa"))return 587;
		if(trip.getFromLocation().equals("Goa") && trip.getToLocation().equals("Delhi"))return 1900;
		if(trip.getFromLocation().equals("Goa") && trip.getToLocation().equals("Jaipur"))return 1630;
		if(trip.getFromLocation().equals("Goa") && trip.getToLocation().equals("Kolkata"))return 1733;
		if(trip.getFromLocation().equals("Goa") && trip.getToLocation().equals("Mumbai"))return 587;
		if(trip.getFromLocation().equals("Jaipur") && trip.getToLocation().equals("Delhi"))return 280;
		if(trip.getFromLocation().equals("Jaipur") && trip.getToLocation().equals("Mumbai"))return 1150;
		if(trip.getFromLocation().equals("Jaipur") && trip.getToLocation().equals("Kolkata"))return 1570;
		if(trip.getFromLocation().equals("Jaipur") && trip.getToLocation().equals("Goa"))return 1630;
		if(trip.getFromLocation().equals("Kolkata") && trip.getToLocation().equals("Delhi"))return 1600;
		if(trip.getFromLocation().equals("Kolkata") && trip.getToLocation().equals("Mumbai"))return 1900;
		if(trip.getFromLocation().equals("Kolkata") && trip.getToLocation().equals("Jaipur"))return 1570;
		if(trip.getFromLocation().equals("Kolkata") && trip.getToLocation().equals("Goa"))return 1733;
		
		return 0;
		
		
		
	}
}