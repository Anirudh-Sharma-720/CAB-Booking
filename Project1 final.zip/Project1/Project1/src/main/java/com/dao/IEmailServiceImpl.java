package com.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.service.IEmailService;
@Service
public class IEmailServiceImpl implements IEmailService{
	@Autowired
	private JavaMailSender mailSend;
	@Override
	public String sendEmail(String to, String body, String subject) {
		// TODO Auto-generated method stub
		SimpleMailMessage msg= new SimpleMailMessage();
		msg.setFrom("anirudh20dec@gmail.com");
		msg.setTo(to);
		msg.setText(body);
		msg.setSubject(subject);
		mailSend.send(msg);
		System.out.println("mail sent ..");
		return "user created";
	}
	
}