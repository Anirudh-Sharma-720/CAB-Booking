import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TripBooking } from 'src/app/model/trip-booking';
import { TripServiceService } from 'src/app/service/trip-service.service';

@Component({
  selector: 'app-trip-list',
  templateUrl: './trip-list.component.html',
  styleUrls: ['./trip-list.component.css']
})
export class TripListComponent implements OnInit {
  trips: TripBooking[] = [];
  constructor(private tripserv:TripServiceService,private router:Router) { }
tripe:TripBooking=new TripBooking();
  ngOnInit(): void {
   this.getTripList();
  }
  getTripList(){
    this.tripserv.getTripList().subscribe(
      data=>{
        this.trips=data;

      },err=>{
        console.log(err);
      }
    )
  }
  viewTrip(tripId:number){
   this.router.navigate(['trip-details/',tripId]);
  }

}

