import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { routerNgProbeToken } from '@angular/router/src/router_module';
import { Admin } from 'src/app/model/admin';
import { Customer } from 'src/app/model/customer';
import { AdminServiceService } from 'src/app/service/admin-service.service';
import { CustomerServiceService } from 'src/app/service/customer-service.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  private userName: string;
  private password: string;
  private userType: string;
  private id: number;
  
  customer: Customer = new Customer();
  admin:Admin=new Admin();

  errorMsg: String;
  showErr: boolean;
  constructor(private custService: CustomerServiceService, private router: Router,private admServ:AdminServiceService) { }

  ngOnInit() {
  }

  doLogin(){
    console.log(this.userType);
    if(this.userType == "admin"){
     this.adminLogin();
    }else if(this.userType == "customer"){
      this.customerLogin();
    }
  }

  customerLogin(){
    
    this.custService.validateUser(this.userName, this.password).subscribe(
      response => {console.log(response);
                    this.customer = response;
                    console.log(this.customer);
                    this.setIdInLocalStorage();
                    this.router.navigate(['user-interface/',this.customer.userId]);
                  },
      err =>{alert("Username/Password doesn't match");
              //   this.errorMsg = err.error.message;
              // this.showErr = true; }
                }
    );
    
  }

  adminLogin(){
   
    this.admServ.validateUser(this.userName, this.password).subscribe(
      response => {console.log(response);
                    this.admin = response;
                    console.log(this.admin);
                    this.setIdInLocalStorage();
                    this.router.navigate(['admin-interface/',this.admin.userId]);
                  },
      err => {console.log("Error2: " + err.error.message);
                this.errorMsg = err.error.message;
              this.showErr = true; }
    );
    
  }

  setIdInLocalStorage(){


    if(this.userType == "admin"){
      localStorage.setItem('userTypee','admin');
      localStorage.setItem('userIdd',JSON.stringify(this.admin.userId));
     }else if(this.userType == "customer"){
      localStorage.setItem('userTypee','customer');
      localStorage.setItem('userIdd',JSON.stringify(this.customer.userId));
     }
  }

  driverLogin(){
    
  }


  getCustomerById(){
    this.custService.getCustomerByID(this.id).subscribe(
      response => {console.log(response)
      
      },
      error => {console.log(error.error);}
    )
  }

  navToCreateCustomer(){
    this.router.navigate(['/create-customer']);
  }


}
