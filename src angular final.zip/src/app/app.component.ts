import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Admin } from './model/admin';
import { Customer } from './model/customer';
import { AdminServiceService } from './service/admin-service.service';
import { CustomerServiceService } from './service/customer-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularCabProject';
  c1:Customer=new Customer();
  a1:Admin=new Admin();
  custS:Customer=new Customer();
  adm:Admin=new Admin();
userid:number;
  id: number;
  constructor(private router: Router, private route: ActivatedRoute,private cust:CustomerServiceService,private adminServ:AdminServiceService) { }

  ngOnInit() {
  //this.id = this.route.snapshot.params['id'];
  this.id=JSON.parse(localStorage.getItem('userIdd'));
  console.log(this.id);
  this.userid=JSON.parse(localStorage.getItem('userIdd'));
  }
getCustomer(){

  if(localStorage.getItem('userTypee')=='customer'){
this.cust.getCustomerByID(this.id).subscribe(
  data=>{
    this.c1=data;
    console.log(data);
    this.router.navigate(['view-customer/',this.id]);
  },err=>{
    console.log(err);
  }

);
  }else{
    if(localStorage.getItem('userTypee')=='admin'){
    
        this.router.navigate(['view-admin/',this.id]);
    }
  }
}
getAdmin(){
  this.adminServ.getAdminById(this.id).subscribe(
    data=>{
      this.a1=data;
      console.log(data);
      this.router.navigate(['view-admin/',this.id]);
    },err=>{
      console.log(err);
    }
  
  );
  }

  navToCustomerTable(){
    this.router.navigate(['customer-table']);
  }

  updateCustomer(){
  if(localStorage.getItem('userTypee')=='customer'){


  
    this.router.navigate(['update-customer/',this.id]);
  }
  else{
    this.router.navigate(['update-admin/',this.id]);
  }
  }

  viewOrders(){
    console.log("View all the cab orders of the customer");
  }
 logOut(){

  localStorage.removeItem('userIdd');
  localStorage.removeItem('userTypee');
  localStorage.removeItem('userIdd');
  this.router.navigate(['']);
 }
 homePage(){




  if(localStorage.getItem('userTypee')=='customer'){


  
    this.router.navigate(['user-interface/',this.id]);
  }
  else{
    this.router.navigate(['admin-interface/',this.id]);
  }




 }
 bookRide(){
  if(localStorage.getItem('userTypee')==null){
    alert("Please Login first");
    this.router.navigate(['']);}
  else{
    this.router.navigate(['create-trip']);
  }
 }
 bookMiniVan(){
if(localStorage.getItem('userTypee')==null)alert("Please Login first");
else{
 localStorage.setItem('carType','MiniVan');
 
//  this.router.navigate(['user-filtercablist/','MiniVan']);
window.location.href = 'user-filtercablist/MiniVan';
 
}
 }
 bookSUV(){
  if(localStorage.getItem('userTypee')==null)alert("Please Login first");
else{
  localStorage.setItem('carType','SUV');

  
  // this.router.navigate(['user-filtercablist/','SUV']);
  window.location.href = 'user-filtercablist/SUV';
  
}

 }
 bookSedan(){
  if(localStorage.getItem('userTypee')==null)alert("Please Login first");
else{
  localStorage.setItem('carType','Sedan');

  window.location.href = 'user-filtercablist/Sedan';
  
}

 }
 viewHistory(){
  if(localStorage.getItem('userTypee')==null)alert("Please Login first");
  else{
    if( localStorage.getItem('userTypee')=='customer'){
  this.cust.getCustomerByID(this.userid).subscribe(

    data=>{
      this.custS=data;
      this.router.navigate(['view-history/',this.custS.userId]);
    },err=>{
      console.log(err);
    }
  );
  }else{
    if( localStorage.getItem('userTypee')=='admin'){
      this.adminServ.getAdminById(this.userid).subscribe(
    
        data=>{
          this.adm=data;
          this.router.navigate(['view-history/',this.adm.userId]);
        },err=>{
          console.log(err);
        }
      );
      }
  }


}
 }
}
