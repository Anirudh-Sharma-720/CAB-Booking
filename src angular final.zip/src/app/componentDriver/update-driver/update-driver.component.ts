import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Driver } from 'src/app/model/driver';
import { DriverServiceService } from 'src/app/service/driver-service.service';

@Component({
  selector: 'app-driver-update',
  templateUrl: './update-driver.component.html',
  styleUrls: ['./update-driver.component.css']
})
export class UpdateDriverComponent implements OnInit {
  userId:number;
  driver:Driver = new Driver();

  constructor(private driverService:DriverServiceService, private router:Router, private route:ActivatedRoute) { }

  ngOnInit() {
    this.userId=this.route.snapshot.params['userId'];
  }

  onSubmit(){
    this.driverService.updateDriver(this.userId, this.driver).subscribe(data=>{
      this.goToDriverList();
    },error=>console.log(error));
  }

  goToDriverList(){
    this.router.navigate(['drivers']);
  }

}
