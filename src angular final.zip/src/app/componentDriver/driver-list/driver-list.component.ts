import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DriverServiceService } from 'src/app/service/driver-service.service';
import { Driver } from 'src/app/model/driver';

@Component({
  selector: 'app-driver-list',
  templateUrl: './driver-list.component.html',
  styleUrls: ['./driver-list.component.css']
})
export class DriverListComponent implements OnInit {
  drivers:Driver[];

  constructor(private driverService:DriverServiceService, private router:Router) { }

  ngOnInit() {
    this.getDrivers();
  }

  private getDrivers(){
    this.driverService.viewAll().subscribe(data =>{
      console.log(data);
      this.drivers = data;
    },error=>{
      console.log(error);
    });
  }

  driverDetails(userId: number){
    this.router.navigate(['driver-details', userId]);
  }

  updateDriver(userId: number){
    this.router.navigate(['update-driver', userId]);
  }

  deleteDriver(userId: number){
    this.driverService.deleteDriver(userId).subscribe( data => {
      console.log(data);
      this.getDrivers();
    })
  }

}
