import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DriverServiceService } from 'src/app/service/driver-service.service';
import { Driver } from 'src/app/model/driver';
import { Cab } from 'src/app/model/cab';
import { CabServiceService } from 'src/app/service/cab-service.service';

@Component({
  selector: 'app-create-driver',
  templateUrl: './create-driver.component.html',
  styleUrls: ['./create-driver.component.css']
})
export class CreateDriverComponent implements OnInit {
  driver:Driver = new Driver();
  cabId:number;
  
  constructor(private driverService:DriverServiceService, private router:Router,private cabServ:CabServiceService) { }

  ngOnInit() {
    
  }

  saveDriver(){
    this.driver.userType="driver";
    this.driver.cab=this.cabId;
    this.driverService.insertDriver(this.driver).subscribe(data =>{
      console.log(data);
      this.goToDriverList();
    },
    error => console.log(error)
    );
  }

  goToDriverList(){
    this.router.navigate(['drivers']);
  }

  onSubmit(){
    console.log(this.driver);
    this.saveDriver();
  }

}
