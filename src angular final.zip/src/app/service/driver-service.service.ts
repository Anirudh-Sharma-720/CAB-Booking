import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Driver } from '../model/driver';
import { Cab } from '../model/cab';
import { Observable } from 'rxjs';
import { ProjectUrl } from '../project-url';


@Injectable({
  providedIn: 'root'
})
export class DriverServiceService {
  url:String=ProjectUrl.getUrl();
  driverId:number;
  licenseNo:string;
  cab:Cab;
  rating:number;
  d:Driver = new Driver();



  constructor(private http: HttpClient) { }

  public extractDriver(userId:number):Observable<Driver>
  {
    return this.http.get<Driver>(`${this.url}`+`driver/v1/driver/view/${userId}/`);
  }

  public insertDriver(driver:Driver)
  {
    return this.http.post(`${this.url}`+`driver/v1/driver/insert`, driver);
  }

  public updateDriver(userId:number, driver:Driver)
  {
    return this.http.put(`${this.url}`+`driver/v1/driver/update/${userId}`, driver);
  }

  public deleteDriver(userId:number)
  {
    return this.http.delete(`${this.url}`+`driver/v1/driver/delete/${userId}`);
  }

  public viewBestDrivers():Observable<any>
  {
    return this.http.get<any>(`${this.url}`+`driver/v1/driver/viewBest`);
  }

  public viewAll():Observable<Driver[]>
  {
    return this.http.get<Driver[]>(`${this.url}`+`driver/v1/driver/viewAll`);
  }

  }

