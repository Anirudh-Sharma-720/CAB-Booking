import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from '../model/admin';
import { ProjectUrl } from '../project-url';
@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
url:String=ProjectUrl.getUrl();
  constructor(private httpClient:HttpClient) { }

  getAdminList():Observable<Admin[]>{
return this.httpClient.get<Admin[]>(`${this.url}`+`admin/v1/admin/getAll`);
  }
  validateUser(userName: string, password: string): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.url}admin/v1/admin/validate/${userName}&${password}`);
  }
  createAdmin(admin:Admin):Observable<Object>{
    return this.httpClient.post(`${this.url}`+`admin/v1/admin/insert`,admin);
  }
  getAdminById(userId:number):Observable<Admin>{
    return this.httpClient.get<Admin>(`${this.url}`+`admin/v1/admin/getById/${userId}`);
  }
  updateAdmin(userId:number,admin:Admin):Observable<Object>{
return this.httpClient.put(`${this.url}`+`admin/v1/admin/update/${userId}`,admin);
  }
  deleteAdmin(userId:number):Observable<Object>{
    return this.httpClient.delete(`${this.url}`+`admin/v1/admin/delete/${userId}`);
  }
  }