import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { TripBooking } from '../model/trip-booking';
import { ProjectUrl } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class TripServiceService {

   url:String = ProjectUrl.getUrl();

  constructor(private httpClient: HttpClient) { }
  
  getTripList(): Observable<TripBooking[]>{
    return this.httpClient.get<TripBooking[]>(`${this.url}`+`trip/v1/trip/getAll`);
  }

  createTrip(trip: TripBooking): Observable<Object>{
    return this.httpClient.post(`${this.url}`+`trip/v1/trip/insert`, trip);
  }

  getTripById(id: number): Observable<TripBooking>{
    return this.httpClient.get<TripBooking>(`${this.url}trip/v1/trip/getById/${id}`);
  }

  updateTrip(id: number, trip: TripBooking): Observable<Object>{
    return this.httpClient.put(`${this.url}trip/v1/trip/update/${id}`, trip);
  }

  deleteTrip(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.url}trip/v1/trip/delete/${id}`);
  }
  viewHistory(id:number):Observable<TripBooking[]>{
    return this.httpClient.get<TripBooking[]>(`${this.url}trip/v1/trips/customer/${id}`);
  }
}