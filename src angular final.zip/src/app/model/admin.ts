import { AbstractUser } from "./abstract-user";

export class Admin extends AbstractUser {
    public adminId:number;
}
