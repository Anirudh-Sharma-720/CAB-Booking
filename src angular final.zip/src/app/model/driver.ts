import { AbstractUser } from "./abstract-user";
import { Cab } from "./Cab";

export class Driver extends AbstractUser{
      driverId:number;
      licenseNo:string;
      cab:number;
      rating:number;

}