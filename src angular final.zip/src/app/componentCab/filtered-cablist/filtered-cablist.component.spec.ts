import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredCablistComponent } from './filtered-cablist.component';

describe('FilteredCablistComponent', () => {
  let component: FilteredCablistComponent;
  let fixture: ComponentFixture<FilteredCablistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredCablistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredCablistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
