import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { TripBooking } from 'src/app/model/trip-booking';
import { CabServiceService } from 'src/app/service/cab-service.service';
import { TripServiceService } from 'src/app/service/trip-service.service';

@Component({
  selector: 'app-user-filtercablist',
  templateUrl: './user-filtercablist.component.html',
  styleUrls: ['./user-filtercablist.component.css']
})
export class UserFiltercablistComponent implements OnInit {
  count: number;
  trip:TripBooking=new TripBooking();
  carType: string;
  cabs: Cab[];
  constructor(private cabService: CabServiceService, private route: ActivatedRoute,private tripServ:TripServiceService,private router:Router) { }

  ngOnInit() {
  
    this.carType=this.route.snapshot.params['carType'];
    this.getCabs();
  }

  getCabs() {
    this.cabService.getCabByType(this.carType).subscribe(data => {
      this.cabs=data;
      console.log(data);
    });
    this.cabService.countCabsByType(this.carType).subscribe(data => {
      this.count=data;
    });
  }
  bookCab(cabi:Cab){
    localStorage.setItem('cab',JSON.stringify(cabi));
    this.router.navigate(['create-trip']);
  }
}
