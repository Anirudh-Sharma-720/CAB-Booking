import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { Driver } from 'src/app/model/driver';
import { CabServiceService } from 'src/app/service/cab-service.service';
import { DriverServiceService } from 'src/app/service/driver-service.service';

@Component({
  selector: 'app-create-cab',
  templateUrl: './create-cab.component.html',
  styleUrls: ['./create-cab.component.css']
})
export class CreateCabComponent implements OnInit {
  cab: Cab=new Cab();
  
  userIdd:number;
  constructor(private cabService: CabServiceService, private router: Router,private driverServ:DriverServiceService) { }

  ngOnInit() {
 
    
  }

  saveCab() {
    
    this.cabService.createCab(this.cab).subscribe( data =>{
      this.goToCabList();
    },
    error => console.log(error));
  }

  goToCabList() {
    this.router.navigate(["/cabs"]);
  }

  onSubmit() {
    console.log(this.cab);
    this.saveCab();
  }
}
