import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserFiltercabComponent } from './user-filtercab.component';

describe('UserFiltercabComponent', () => {
  let component: UserFiltercabComponent;
  let fixture: ComponentFixture<UserFiltercabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserFiltercabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserFiltercabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
