import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';

@Component({
  selector: 'app-user-filtercab',
  templateUrl: './user-filtercab.component.html',
  styleUrls: ['./user-filtercab.component.css']
})
export class UserFiltercabComponent implements OnInit {
  cab: Cab=new Cab();
  constructor(private router: Router) { }

  ngOnInit() {
  }
  
  filterCab(carType: string) {
    this.router.navigate(["user-filtercablist", carType]);
  }
}
