import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cab } from 'src/app/model/cab';
import { CabServiceService } from 'src/app/service/cab-service.service';

@Component({
  selector: 'app-user-cablist',
  templateUrl: './user-cablist.component.html',
  styleUrls: ['./user-cablist.component.css']
})
export class UserCablistComponent implements OnInit {
  cabs: Cab[];
  
  constructor(private cabService: CabServiceService, private router: Router) { }

  ngOnInit(): void {
    this.getCabs();
  }

  private getCabs() {
    this.cabService.getCabList().subscribe(data => {
      this.cabs=data;
    });
  }
}
