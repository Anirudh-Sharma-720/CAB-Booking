import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCablistComponent } from './user-cablist.component';

describe('UserCablistComponent', () => {
  let component: UserCablistComponent;
  let fixture: ComponentFixture<UserCablistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCablistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCablistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
