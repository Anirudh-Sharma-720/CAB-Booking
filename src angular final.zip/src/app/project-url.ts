export class ProjectUrl {

    public static getUrl():String
    {
return "http://localhost:2710/";
    }
}
