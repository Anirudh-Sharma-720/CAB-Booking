import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/model/customer';
import { CustomerServiceService } from 'src/app/service/customer-service.service';

@Component({
  selector: 'app-customer-table',
  templateUrl: './customer-table.component.html',
  styleUrls: ['./customer-table.component.css']
})
export class CustomerTableComponent implements OnInit {

  customers: Customer[];
  constructor(private customerService: CustomerServiceService, private router: Router) { }

  ngOnInit() {
    this.getCustomers();
    
  }

  getCustomers(){

    this.customerService.getCustomerList().subscribe(
      response => {this.customers = response;
        console.log(this.customers)}
    );
  }

  updateCustomer(id: number){
    console.log(id);
    this.router.navigate(['update-customer', id]);
  }

  deleteCustomer(id: number){
    this.customerService.deleteCustomer(id).subscribe(
      response => {console.log(response);
        window.location.reload();
      }
    );
 
    //this.router.navigate(['customer-table']);
  }

  viewCustomer(id: number){
    console.log("view Customer to be implemented: " + id);
    this.router.navigate(['view-customer/',id]);
  }

}
