import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Admin } from 'src/app/model/admin';
import { AdminServiceService } from 'src/app/service/admin-service.service';

@Component({
  selector: 'app-update-admin',
  templateUrl: './update-admin.component.html',
  styleUrls: ['./update-admin.component.css']
})
export class UpdateAdminComponent implements OnInit {
userId:number;
admin:Admin=new Admin();
  constructor(private admServ:AdminServiceService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.userId=this.route.snapshot.params['id'];
   
  }
  onSubmit(){
    this.admServ.updateAdmin(this.userId,this.admin).subscribe(data=>{
      this.getAdminList();
    });
  }
  getAdminList(){
    window.location.reload();
  }

}
